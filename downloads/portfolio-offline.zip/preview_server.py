"""Serve only the independent portfolio preview, bound to this machine."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from functools import partial
import sys, urllib.request, webbrowser

# This file is copied into the output directory; its parent is the served root.
ROOT = Path(__file__).resolve().parent
class Handler(SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/__portfolio_preview__':
            self.send_response(200)
            self.send_header('Content-Type','text/plain; charset=utf-8')
            self.end_headers(); self.wfile.write(b'bao-portfolio-aigc-preview'); return
        return super().do_GET()
    def list_directory(self, path):
        self.send_error(403, 'Directory listing disabled')

if __name__ == '__main__':
    for port in range(5186,5191):
        address=f'http://127.0.0.1:{port}'
        try:
            with urllib.request.urlopen(address+'/__portfolio_preview__',timeout=.3) as response:
                if response.read()==b'bao-portfolio-aigc-preview':
                    if '--open' in sys.argv: webbrowser.open(address+'/index.html')
                    print(address,flush=True);sys.exit(0)
        except Exception: pass
        try: server=ThreadingHTTPServer(('127.0.0.1',port),partial(Handler,directory=str(ROOT)))
        except OSError: continue
        print(address,flush=True)
        if '--open' in sys.argv: webbrowser.open(address+'/index.html')
        server.serve_forever();break
    else: raise SystemExit('No preview port available (5186-5190)')

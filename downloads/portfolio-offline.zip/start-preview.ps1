﻿$ErrorActionPreference = 'Stop'
$previewPython = 'D:/767/python3/python.exe'
if (!(Test-Path -LiteralPath $previewPython)) { $previewPython = (Get-Command python -ErrorAction Stop).Source }
$previewArgs = '"' + (Join-Path $PSScriptRoot 'preview_server.py') + '" --open'
Start-Process -FilePath $previewPython -ArgumentList $previewArgs -WindowStyle Hidden
